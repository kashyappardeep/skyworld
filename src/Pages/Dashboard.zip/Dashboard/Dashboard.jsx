import React, { useEffect, useState } from "react";
import "./Dashboard.css";
import "./Slot.css";
import { Row, Col } from "react-bootstrap";
import { FaTelegramPlane } from "react-icons/fa";
import { BsInfoCircle } from "react-icons/bs";
import RankStatar from "./../../Images/rankStatar.png";
import RankSilver from "./../../Images/rankSilver.png";
import RankPearl from "./../../Images/rankPearl.png";
import RankGold from "./../../Images/rankGold.png";
import RankEmerald from "./../../Images/rankEmerald.png";
import RankDiamond from "./../../Images/rankDiamond.png";
import RankCrowdDiamond from "./../../Images/rankCrowdDiamond.png";
import RankRoyalDiamond from "./../../Images/rankRoyalDiamond.png";
import Meta from "./../../Images/meta.png";
import yourRank from "./../../Images/yourrank.png";
import Wallet from "./../../Images/wallet.png";
import Meating from "./../../Images/meeting.png";
import Team from "./../../Images/team.png";
import { ApiPaths } from "../../Config";
import axios from "axios";
import Loader from "../../Components/Loader/Loader";
import InfoPage from "../../Components/InfoPage/InfoPage";
import { Link } from "react-router-dom";
import { BsArrowUpRightCircleFill } from "react-icons/bs";
import { ToastContainer, toast } from "react-toastify";
import Timer from "../../Components/Timer";
import { Data } from "../../Common/Data";
import MyChart from "../../Components/MyChart/MyChart";
import { GiCycle } from "react-icons/gi";
import Slot from "./Slot";

const Dashboard = () => {
  const [loading, setLoading] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [dashboardData, setDashboardData] = useState([]);
  const [myRank, setMyRank] = useState();
  const [incomeInfo, setIncomeInfo] = useState(false);
  const [incomeHeading, setIncomeHeading] = useState(false);
  const [infoData, setInfoData] = useState();
  let x = 0;
  useEffect(() => {
    if (x === 0) {
      checkData();
      x = 1;
    }
  }, []);
  const toastSuccess = (msg) => toast.success(msg);
  const toastFailed = (msg) => toast.error(msg);
  function IncomeInfoState(newstate) {
    setIncomeInfo(newstate);
  }

  function InfoPageData(heading, data) {
    Data.isDebug && console.log(heading);
    setIncomeHeading(heading);
    setInfoData(data);
    setIncomeInfo(true);
  }

  function checkData() {
    let jsondata = localStorage.getItem("dashboardData");
    const data = JSON.parse(jsondata);
    Data.isDebug && console.log("data", data);
    if (data) {
      setDashboardData(data);
      setMyRank(data?.profile?.[0]?.my_rank);
      FetchData();
    } else {
      FetchData(true);
    }
  }

  function FetchData(checkload) {
    if (checkload) {
      setLoading(true);
    }
    let userId = localStorage.getItem("userId");
    Data.isDebug && console.log("user id", userId);
    axios({
      method: "post",
      url: ApiPaths.dashboard,
      data: {
        u_id: userId,
      },
      headers: {
        "Content-Type": "multipart/form-data",
      },
    })
      .then(function (response) {
        Data.isDebug && console.log(response);
        setDashboardData(response?.data);
        Data.isDebug &&
          console.log("first", response?.data?.profile?.[0]?.my_rank);
        setMyRank(response?.data?.profile?.[0]?.my_rank);
        localStorage.setItem("dashboardData", JSON.stringify(response?.data));
        setLoading(false);
      })
      .catch(function (response) {
        Data.isDebug && console.log(response);
        setLoading(false);
      });
  }
  function metaRequest() {
    setSubmitLoading(true);
    let userId = localStorage.getItem("userId");
    axios({
      method: "post",
      url: ApiPaths.metaRequest,
      data: {
        u_id: userId,
      },
      headers: {
        "Content-Type": "multipart/form-data",
      },
    })
      .then(function (response) {
        Data.isDebug && console.log(response);
        if (response?.data?.res == "success") {
          toastSuccess(response?.data?.message);
        } else {
          toastFailed(response?.data?.message);
        }
        setSubmitLoading(false);
      })
      .catch(function (response) {
        Data.isDebug && console.log(response);
        setSubmitLoading(false);
      });
  }

  return (
    <>
      {loading ? <Loader /> : null}
      {incomeInfo ? (
        <InfoPage
          updateState={IncomeInfoState}
          heading={incomeHeading}
          data={infoData}
        />
      ) : null}
      <ToastContainer />
      <section className="dashboard">
        <h1 className="textHeading">Dashboard</h1>
        <Row>
          <Col lg="6">
            <Row style={{ height: "100%" }}>
              <Col md="6" className="mb">
                <div className="dashboardMainAccountCard d-flex flex-column justify-content-between">
                  <h5 className="dashboardCardHeading">Main Account</h5>
                  <div className="metaDiv">
                    <div>
                      <img src={Meta} alt="" />
                    </div>
                    <p>Trading Account</p>
                  </div>
                  <div>
                    {submitLoading ? (
                      <div className="otpLoading"></div>
                    ) : (
                      <button onClick={metaRequest} className="btnPrimary">
                        Submit
                      </button>
                    )}
                    <div className="d-flex gap-2">
                      <Link
                        to="add_fund"
                        className="flex-1"
                        style={{ width: "100%" }}
                      >
                        <button className="btnPrimary">Deposit</button>
                      </Link>
                      <Link
                        to="withdraw"
                        className="flex-1"
                        style={{ width: "100%" }}
                      >
                        <button className="btnPrimary">Withdraw</button>
                      </Link>
                    </div>
                  </div>
                </div>
              </Col>
              <Col md="6" className="mb">
                <div className="dashboardRankCard">
                  <div className="d-flex align-items-center justify-content-between mb-2">
                    <h5 className="dashboardCardHeading m-0">Rank</h5>
                    <i
                      className="infoIcon"
                      onClick={() =>
                        InfoPageData(
                          "Rank",
                          <div>
                            <p>The total number of ranks is 8</p>
                            <h5>Rank 1 is Starter</h5>
                            <p>
                              if your activation package is $100 then you get
                              15% income from this rank
                            </p>
                            <h5>Rank 2 is silver</h5>
                            <p>
                              if the team has 5 starter rank achievers or there
                              is a community profit of $1k then you get 20%
                              income from this rank
                            </p>
                            <h5>Rank 3 is a Pearl</h5>
                            <p>
                              if the team has 2 Silver rank achievers or there
                              is a community profit of $3k then you get 30%
                              income from this rank.
                            </p>
                            <h5>Rank 4 is a Gold</h5>
                            <p>
                              if the team has 2 Pearl rank achievers or there is
                              a community profit of $10k then you get 40% income
                              from this rank.
                            </p>
                            <h5>Rank 5 is an Emerald</h5>
                            <p>
                              if the team has 3 Gold rank achievers or there is
                              a community profit of $50k then you get 50% income
                              from this rank.
                            </p>
                            <h5>Rank 6 is a Diamond</h5>
                            <p>
                              if the team has 3 Emerald rank achievers or there
                              is a community profit of $2lac then you get 60%
                              income from this rank.
                            </p>
                            <h5>Rank 7 is a Crown Diamond</h5>
                            <p>
                              if the team has 3 Diamond rank achievers or there
                              is a community profit of $10lac then you get 70%
                              income from this rank.
                            </p>
                            <h5>Rank 8 is a Royal Diamond</h5>
                            <p>
                              if the team has 3 Crown diamond rank achievers or
                              there is a community profit of $50lac then you get
                              80% income from this rank.
                            </p>
                          </div>
                        )
                      }
                    >
                      <BsInfoCircle />
                    </i>
                  </div>
                  <Link to="reward">
                    {myRank == "STATAR" ? (
                      <img src={RankStatar}></img>
                    ) : myRank == "SILVER" ? (
                      <img src={RankSilver}></img>
                    ) : myRank == "PEARL" ? (
                      <img src={RankPearl}></img>
                    ) : myRank == "GOLD" ? (
                      <img src={RankGold}></img>
                    ) : myRank == "EMERALD" ? (
                      <img src={RankEmerald}></img>
                    ) : myRank == "DIAMOND" ? (
                      <img src={RankDiamond}></img>
                    ) : myRank == "CROWD DIAMOND" ? (
                      <img src={RankCrowdDiamond}></img>
                    ) : myRank == "ROYAL DIAMOND" ? (
                      <img src={RankRoyalDiamond}></img>
                    ) : (
                      <img src={yourRank}></img>
                    )}
                  </Link>
                  <div className="aboutDetails">
                    <p>AI Subscription</p>
                    <h5>{dashboardData?.ai_subcription ?? "0"}</h5>
                  </div>
                  <div className="aboutDetails">
                    <p>Package</p>
                    <h5>{dashboardData?.pack ?? "0"}</h5>
                  </div>
                  <div className="aboutDetails">
                    <p>Package Amount</p>
                    <h5>{dashboardData?.package_amount ?? "0"}</h5>
                  </div>
                  <div className="aboutDetails">
                    <p>Bonus</p>
                    <h5>{dashboardData?.bonus ?? "0"}</h5>
                  </div>
                  <div className="aboutDetails">
                    <p>AI Remaining Date</p>
                    {/* <h5>{dashboardData?.effectiveDate ?? "0"}</h5> */}
                    {dashboardData?.effectiveDate && (
                      <Timer time={dashboardData?.effectiveDate} />
                    )}
                  </div>
                </div>
              </Col>
            </Row>
          </Col>
          <Col
            lg="6"
            className="gap-2 d-flex flex-column justify-content-between"
          >
            <Row>
              <Col md="6" className="mb-2">
                <div className="dashboardIncomeCard">
                  <div>
                    <h5 className="dashboardCardHeading">Daily Trade Profit</h5>
                    <i
                      className="infoIcon"
                      onClick={() =>
                        InfoPageData(
                          "Daily Trade Profit",
                          <p>
                            In this, you get 30% trading income of the
                            subscription package on a daily basis.
                          </p>
                        )
                      }
                    >
                      <BsInfoCircle />
                    </i>
                  </div>
                  <h1>
                    {parseFloat(
                      dashboardData?.incomes?.daily_trade ?? "0"
                    ).toFixed(2)}
                  </h1>
                </div>
              </Col>
              <Col md="6" className="mb-2">
                <div className="dashboardIncomeCard">
                  <div>
                    <h5 className="dashboardCardHeading">Trading Bonus</h5>
                    <i
                      className="infoIcon"
                      onClick={() =>
                        InfoPageData(
                          "Trading Bonus",
                          <p>
                            In this, depending on the packages, you get a
                            trading bonus for 10 working days which ranges from
                            0% to 40% according to different packages.
                          </p>
                        )
                      }
                    >
                      <BsInfoCircle />
                    </i>
                  </div>
                  <h1>
                    ${" "}
                    {parseFloat(
                      dashboardData?.incomes?.self_bonus ?? "0"
                    ).toFixed(2)}
                  </h1>
                </div>
              </Col>
              <Col md="6" className="mb-2">
                <div className="dashboardIncomeCard">
                  <div>
                    <h5 className="dashboardCardHeading">Same Rank Income</h5>
                    <i
                      className="infoIcon"
                      onClick={() =>
                        InfoPageData(
                          "Same Rank Income",
                          <p>
                            If a member in your direct downline achieves the
                            same rank as you, you will receive a 0.05% income.
                          </p>
                        )
                      }
                    >
                      <BsInfoCircle />
                    </i>
                  </div>
                  <h1>
                    ${" "}
                    {parseFloat(
                      dashboardData?.incomes?.same_rank ?? "0"
                    ).toFixed(2)}
                  </h1>
                </div>
              </Col>
              <Col md="6" className="mb-2">
                <div className="dashboardIncomeCard">
                  <div>
                    <h5 className="dashboardCardHeading">Rank Income</h5>
                    <i
                      className="infoIcon"
                      onClick={() =>
                        InfoPageData(
                          "Rank Income",
                          <div>
                            <p>This Shows your Rank Income</p>
                            <p>The total number of ranks is 8</p>
                            <h5>Rank 1 is Starter</h5>
                            <p>
                              if your activation package is $100 then you get
                              15% income from this rank
                            </p>
                            <h5>Rank 2 is silver</h5>
                            <p>
                              if the team has 5 starter rank achievers or there
                              is a community profit of $1k then you get 20%
                              income from this rank
                            </p>
                            <h5>Rank 3 is a Pearl</h5>
                            <p>
                              if the team has 2 Silver rank achievers or there
                              is a community profit of $3k then you get 30%
                              income from this rank.
                            </p>
                            <h5>Rank 4 is a Gold</h5>
                            <p>
                              if the team has 2 Pearl rank achievers or there is
                              a community profit of $10k then you get 40% income
                              from this rank.
                            </p>
                            <h5>Rank 5 is an Emerald</h5>
                            <p>
                              if the team has 3 Gold rank achievers or there is
                              a community profit of $50k then you get 50% income
                              from this rank.
                            </p>
                            <h5>Rank 6 is a Diamond</h5>
                            <p>
                              if the team has 3 Emerald rank achievers or there
                              is a community profit of $2lac then you get 60%
                              income from this rank.
                            </p>
                            <h5>Rank 7 is a Crown Diamond</h5>
                            <p>
                              if the team has 3 Diamond rank achievers or there
                              is a community profit of $10lac then you get 70%
                              income from this rank.
                            </p>
                            <h5>Rank 8 is a Royal Diamond</h5>
                            <p>
                              if the team has 3 Crown diamond rank achievers or
                              there is a community profit of $50lac then you get
                              80% income from this rank.
                            </p>
                          </div>
                        )
                      }
                    >
                      <BsInfoCircle />
                    </i>
                  </div>
                  <h1>
                    ${" "}
                    {parseFloat(
                      dashboardData?.incomes?.rank_profit ?? "0"
                    ).toFixed(2)}
                  </h1>
                </div>
              </Col>

              <Col md="6" className="mb-2">
                <div className="dashboardIncomeCard">
                  <div>
                    <h5 className="dashboardCardHeading">
                      AI Subscribe Affiliate Income
                    </h5>
                    <i
                      className="infoIcon"
                      onClick={() =>
                        InfoPageData(
                          "AI Subscribe Affiliate Income",
                          <div>
                            <p>
                              This is a type of affiliate bonus income when you
                              share this plan with someone else.
                            </p>
                            <p>
                              This income is structured with different
                              percentages from level 01 to level 31, as follows:
                            </p>
                            <p>- Level 01: 25%</p>
                            <p>- Level 02: 10%</p>
                            <p>- Level 03 to 04: 5%</p>
                            <p>- Level 05 to 06: 4%</p>
                            <p>- Level 07 to 08: 3%</p>
                            <p>- Level 09: 2%</p>
                            <p>- Level 10: 5%</p>
                            <p>- Level 11 to 19: 1%</p>
                            <p>- Level 20: 5%</p>
                            <p>- Level 21 to 30: 0.5%</p>
                            <p>- Level 31: 5%</p>
                            <p>
                              Note: Achieving a 70:30 ratio is mandatory to
                              receive the Affiliate Bonus.
                            </p>
                          </div>
                        )
                      }
                    >
                      <BsInfoCircle />
                    </i>
                  </div>
                  <h1>
                    ${" "}
                    {parseFloat(
                      dashboardData?.incomes?.affilate ?? "0"
                    ).toFixed(2)}
                  </h1>
                </div>
              </Col>
              <Col md="6" className="mb-2">
                <div className="dashboardIncomeCard">
                  <div>
                    <h5 className="dashboardCardHeading">
                      Gambit Development Bonus
                    </h5>
                    <i
                      className="infoIcon"
                      onClick={() =>
                        InfoPageData(
                          "Gambit Development Bonus",
                          <div>
                            <p>
                              This is a type of royalty income that can be
                              earned when certain achievements are fulfilled,
                              and you receive it every month. Here is a
                              description of it:
                            </p>
                            <h5>Pearl</h5>
                            <p>
                              If you have 5 active achievers in your direct
                              network, you will receive $500 per month.
                            </p>
                            <h5>Emerald </h5>
                            <p>
                              If you have 4 active achievers at the Emerald
                              level in your direct network, you will receive
                              $1000 per month.
                            </p>
                            <h5>Diamond</h5>
                            <p>
                              If you have 4 active achievers at the Diamond
                              level in your direct network, you will receive
                              $2000 per month.
                            </p>
                            <h5>Crown Diamond</h5>
                            <p>
                              If you have 4 active achievers at the Crown
                              Diamond level in your direct network, you will
                              receive $5000 per month.
                            </p>
                            <h5>Royal Diamond </h5>
                            <p>
                              If you have 4 active achievers at the Royal
                              Diamond level in your direct network, you will
                              receive $10,000 per month.
                            </p>
                            <h5>
                              In addition to this, the company also organizes
                              foreign trips.
                            </h5>
                          </div>
                        )
                      }
                    >
                      <BsInfoCircle />
                    </i>
                  </div>
                  <h1>{dashboardData?.incomes?.development_bonus ?? "0"}</h1>
                </div>
              </Col>
              <Col md="6" className="mb-2">
                <div className="dashboardIncomeCard">
                  <div>
                    <h5 className="dashboardCardHeading">Royalty Income</h5>
                    <i className="infoIcon">
                      <BsInfoCircle />
                    </i>
                  </div>
                  <h1>{dashboardData?.incomes?.royalty ?? "0"}</h1>
                </div>
              </Col>
              <Col md="6" className="mb-2">
                <div className="dashboardIncomeCard">
                  <div>
                    <h5 className="dashboardCardHeading">Reward Income</h5>
                    <i className="infoIcon">
                      <BsInfoCircle />
                    </i>
                  </div>
                  <h1>{dashboardData?.incomes?.reward ?? "0"}</h1>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>
        <Row className="mt-3">
          <Col md="4" className="mb-2">
            <div className="dashboardIncomeCard">
              <div>
                <h5 className="dashboardCardHeading">4X Matrix Income</h5>
              </div>
              <h1>
                ${" "}
                {parseFloat(
                  dashboardData?.incomes?.g1_pool_income ?? "0"
                ).toFixed(2)}
              </h1>
            </div>
          </Col>
          <Col md="4" className="mb-2">
            <div className="dashboardIncomeCard">
              <div>
                <h5 className="dashboardCardHeading">2X4 Matrix Income</h5>
              </div>
              <h1>
                ${" "}
                {parseFloat(
                  dashboardData?.incomes?.g2_pool_income ?? "0"
                ).toFixed(2)}
              </h1>
            </div>
          </Col>
          <Col md="4" className="mb-2">
            <div className="dashboardIncomeCard">
              <div>
                <h5 className="dashboardCardHeading">
                  Global Auto Matrix Income
                </h5>
              </div>
              <h1>
                ${" "}
                {parseFloat(
                  dashboardData?.incomes?.g3_pool_income ?? "0"
                ).toFixed(2)}
              </h1>
            </div>
          </Col>
        </Row>
        <section className="mt-3">
          <Row>
            <Col lg="4" className="mb-2">
              <div className="wallets">
                <div className="walletsIconDiv">
                  <div className="walletsImg">
                    {" "}
                    <img src={Wallet} alt="" />
                    <h1>Wallets</h1>
                  </div>
                  <i
                    onClick={() =>
                      InfoPageData(
                        "Wallets",
                        <div>
                          <h5>Main Wallet </h5>
                          <p>
                            displays your total income and is used for
                            withdrawals.
                          </p>
                          <h5>Fund Wallet</h5>
                          <p>
                            This wallet shows the funds where team bonuses or
                            other incomes are linked, or where withdrawal
                            transfer amounts are displayed. This wallet is used
                            for ID activation.
                          </p>
                          <h5>Package Wallet</h5>
                          <p>
                            This wallet shows your active package amount. If you
                            claim within 30 days, the package balance is shown
                            in this wallet, which you can either redeem or use
                            to activate your ID again.
                          </p>
                        </div>
                      )
                    }
                  >
                    <BsInfoCircle />
                  </i>
                </div>
                <div className="walletsData">
                  <p>Main Wallet</p>
                  <p>
                    ${" "}
                    {parseFloat(dashboardData?.wallets?.main_wallet).toFixed(2)}
                  </p>
                </div>
                <div className="walletsData">
                  <p>Fund Wallet</p>
                  <p>
                    ${" "}
                    {parseFloat(dashboardData?.wallets?.fund_wallet).toFixed(2)}
                  </p>
                </div>
                <div className="walletsData">
                  <p>Package Wallet</p>
                  <p>
                    ${" "}
                    {parseFloat(dashboardData?.wallets?.package_wallet).toFixed(
                      2
                    )}
                  </p>
                </div>
              </div>
            </Col>
            <Col lg="4" className="mb-2">
              <div className="wallets">
                <div className="walletsIconDiv">
                  <div className="walletsImg">
                    {" "}
                    <img src={Team} alt="" />
                    <h1>Team</h1>
                  </div>
                  <i
                    onClick={() =>
                      InfoPageData(
                        "Team",
                        <div>
                          <h5>Active Directs</h5>
                          <p>
                            Number of Direct Joinings who are active with the
                            plan.
                          </p>
                          <h5>Inactive Directs</h5>
                          <p>
                            Number of Direct Joinings who have not yet taken any
                            plan. Need to To take a subscription plan.
                          </p>
                          <h5>Total Team</h5>
                          <p>
                            Total numbers of active and Inactive Direct or
                            Indirect Joinings
                          </p>
                          <h5>Active Team</h5>
                          <p>
                            Number of Direct and Indirect Joinings who are
                            active plans.
                          </p>
                        </div>
                      )
                    }
                  >
                    <BsInfoCircle />
                  </i>
                </div>
                <div className="walletsData">
                  <p>Active Directs</p>
                  <p>{dashboardData?.teams?.active_directs}</p>
                </div>
                <div className="walletsData">
                  <p>Inactive Directs</p>
                  <p>{dashboardData?.teams?.inactive_directs}</p>
                </div>
                <div className="walletsData">
                  <p>Total Team</p>
                  <p>{dashboardData?.teams?.total_gen}</p>
                </div>
                <div className="walletsData">
                  <p>Active Team</p>
                  <p>{dashboardData?.teams?.active_gen}</p>
                </div>
              </div>
            </Col>
            <Col lg="4" className="mb-2">
              <div className="wallets">
                <div className="walletsIconDiv">
                  <div className="walletsImg">
                    {" "}
                    <img src={Meating} alt="" />
                    <h1>Business Statistics</h1>
                  </div>
                  <i
                    onClick={() =>
                      InfoPageData(
                        "Business Statistics",
                        <div>
                          <h5>Power</h5>
                          <p>
                            This displays the business amount in the power leg,
                            the leg where your team has generated the most
                            business.
                          </p>
                          <h5>Weaker</h5>
                          <p>
                            This shows the business amount in the weaker leg,
                            the leg where your team has generated less business.
                          </p>
                          <h5>Matching % </h5>
                          <p>
                            This displays the matching income. Whenever a
                            business pair is formed, the matching percentage is
                            calculated from it.
                          </p>
                          <h5>Team Business </h5>
                          <p>
                            This shows the business of your direct and indirect
                            team members.
                          </p>
                          <h5>Community Businesses </h5>
                          <p>
                            This displays the business of your indirect team
                            members.
                          </p>
                        </div>
                      )
                    }
                  >
                    <BsInfoCircle />
                  </i>
                </div>

                <div className="walletsData">
                  <p>Power</p>
                  <p>{parseFloat(dashboardData?.power).toFixed(2)}</p>
                </div>
                <div className="walletsData">
                  <p>Weaker</p>
                  <p>{parseFloat(dashboardData?.weaker).toFixed(2)}</p>
                </div>
                <div className="walletsData">
                  <p>Matching %</p>
                  <p>{parseFloat(dashboardData?.matching).toFixed(2)}</p>
                </div>
                <div className="walletsData">
                  <p>Team Business</p>
                  <p>{parseFloat(dashboardData?.team_business).toFixed(2)}</p>
                </div>
                <div className="walletsData">
                  <p>Community Business</p>
                  <p>{parseFloat(dashboardData?.total_community).toFixed(2)}</p>
                </div>
              </div>
            </Col>
          </Row>
        </section>
        <section className="cappingSection">
          <div className="viewCappingDiv">
            <h1 className="textHeadingWithMargin">Capping</h1>
            <Link to="capping">
              <p>View All</p>
              <i>
                <BsArrowUpRightCircleFill />
              </i>
            </Link>
          </div>
          {dashboardData != null && dashboardData ? (
            <MyChart
              className="dashboardChart"
              data={dashboardData?.pkg_info}
            />
          ) : (
            ""
          )}
        </section>
        <Row className="mt-4 dashboardBtn">
          <Col md="3" xs="6">
            <Link to="development_bonus">
              <button className="btnPrimary">Gambit Development Bonus</button>
            </Link>
          </Col>
          <Col md="3" xs="6">
            <Link to="news">
              <button className="btnPrimary">Market News</button>
            </Link>
          </Col>
          <Col md="3" xs="6">
            <Link to="plans">
              <button className="btnPrimary">Packages</button>
            </Link>
          </Col>
          <Col md="3" xs="6">
            <Link to="market">
              <button className="btnPrimary">Market</button>
            </Link>
          </Col>
        </Row>

        <Slot />

        <section className="news">
          <h1 className="textHeadingWithMargin">News</h1>
          <Row>
            <Col md="8" className="mb">
              <div className="newsDiv">
                <Row>
                  <Col lg="6">
                    <div className="dashboardNewsCard">
                      <img
                        src={dashboardData?.latest_news?.urlToImage}
                        alt="img.jpg"
                      />
                      <p>{dashboardData?.latest_news?.publishedAt}</p>
                      <h3>{dashboardData?.latest_news?.title}</h3>
                      <h5>{dashboardData?.latest_news?.description}</h5>
                      <Link to="news">
                        <button className="btnSecondary mt-4 newsMobile">
                          More news
                        </button>
                      </Link>
                    </div>
                  </Col>
                  <Col lg="6">
                    <div className="dashboardNewsCardRight">
                      <h5 className="dashboardCardHeading">Latest News</h5>
                      <h4>{dashboardData?.latest_news?.description}</h4>
                      <h3>{dashboardData?.latest_news?.publishedAt}</h3>
                      <Link to="news">
                        <button className="btnSecondary">More news</button>
                      </Link>
                    </div>
                  </Col>
                </Row>
              </div>
            </Col>
            <Col md="4">
              <div className="presentation">
                <div>
                  <h5 className="dashboardCardHeading">Presentation</h5>
                  {/* <a href={dashboardData?.pdf}><img src={dashboardData?.pdf} alt="pdf" /></a> */}
                  <iframe
                    title="PDF Viewer"
                    src={dashboardData?.pdf} // Replace with the actual PDF URL
                    style={{ width: "100%", height: "100%" }}
                  ></iframe>
                </div>
                <div className="d-flex gap-2">
                  <button
                    className="btnSecondary"
                    onClick={() => window.open(dashboardData?.pdf, "_blank")}
                  >
                    View
                  </button>
                  <a
                    href={dashboardData?.pdf}
                    download={true}
                    className="btnSecondary text-center"
                  >
                    Download
                  </a>
                </div>
              </div>
            </Col>
          </Row>
        </section>
        <h1 className="textHeadingWithMargin">Telegram</h1>
        <div className="telegramBotDiv">
          <Row className="align-items-center">
            <Col md="6">
              <div id="telegramBotDivText">
                <i>
                  <FaTelegramPlane />
                </i>
                <div>
                  <h5>Gambitbot Notifier</h5>
                  <p>New partners and transactions notifications</p>
                </div>
              </div>
            </Col>
            <Col md="6">
              <button
                onClick={() =>
                  window.open(dashboardData?.telegram_link, "_blank")
                }
                className="btnPrimary"
              >
                Connect
              </button>
            </Col>
          </Row>
        </div>
      </section>
    </>
  );
};

export default Dashboard;
